//
//  FirstApplApp.swift
//  FirstAppl
//
//  Created by Apprenant66 on 05/03/2024.
//

import SwiftUI

@main
struct FirstApplApp: App {
    var body: some Scene {
        WindowGroup {
            Tabview()
        }
    }
}
