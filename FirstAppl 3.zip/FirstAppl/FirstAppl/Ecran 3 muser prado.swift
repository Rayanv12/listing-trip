//
//  Ecran activité 8.swift
//  Exercice1
//
//  Created by Massidé DOSSO on 19/03/2024.
//

import SwiftUI

struct Ecran_activite__8: View {
    init() {
        UINavigationBar.appearance().largeTitleTextAttributes = [.foregroundColor: UIColor(Color("orangec"))]
    }
    var Prado = Activité(titre: "Musée du prado", description: "Le musée possède la collection de peinture Espagnol la plus complète au monde. Découvrez aussi de nombreuses peinture Italiennen lors de votre visite dans le musée du Prado. Vous avez la possibilité de visiter le musée gratuitement du lundi au samedi de 18 heures à 20 heures et le dimanche de 17 heures à 19 heures.", image:"Rectangle 118-2", budjet: 75, categorie: "Culture", choisi: false, adresse: "Paseo del Prado s/n 28014 Madrid", telephone:"+34913302800", tempsActivitée: "2 heures", lienweb: "https://www.museodelprado.es")
    
    var body: some View {
        
        ZStack {
            Color(.jaune)
            
            
            VStack {
                
                
                VStack {

                    ZStack {
                        Rectangle()
                            .frame(width: 130, height: 50)
                            .foregroundColor(.white)
                            .clipShape(UnevenRoundedRectangle(cornerRadii: .init(topLeading: 20, bottomLeading: 0, bottomTrailing: 0, topTrailing: 20)))
                            .shadow(color: .yellow, radius: 0, x: 8, y: 1)

                        VStack {
                            Text(Prado.categorie)
                            .bold()
                            .padding(.bottom, -4.0)

                                }
                        }
                    
                        .padding(.trailing, 240.0)
                    }
                

                .padding(.bottom, -9.0)

                VStack {
                    
                    
                    Image("prado")
                        .resizable()
                        .scaledToFill()
                        .frame(width: 370, height: 150, alignment: .center)
                        .clipShape(UnevenRoundedRectangle(cornerRadii: .init(topLeading: 0, bottomLeading: 0, bottomTrailing: 0, topTrailing: 30)))
                        .shadow(radius: 10, x: 1, y: 10)

                    
                        .padding(.bottom, -24.0)
                       // .padding(.horizontal, 19.0)

                    
            VStack {
                 ZStack {
                        Rectangle()
                         .clipShape(UnevenRoundedRectangle(cornerRadii: .init(topLeading: 0, bottomLeading: 30, bottomTrailing: 30, topTrailing: 0)))
                            .frame(width: 370, height: 380)
                            .foregroundColor(Color.white)
                            .shadow(radius: 10, x: 1, y: 10)

                        VStack (alignment: .leading) {
                            Text(Prado.titre)
                                .font(.largeTitle)
                                .padding(.bottom)

                            Text("Tarifs de groupe: \(Prado.budjet) €")
                            Text(Prado.tempsActivitée)
                            Text(Prado.adresse)
                            Text(Prado.telephone)
                                .padding(.bottom)
                            Text(Prado.description)
                            Text(Prado.lienweb)
                            }
                        .padding(.horizontal, 19.0)
                        }
                 .padding()

                    }
                    
                    
                }
                
                VStack {
                    NavigationLink {
                        application_ecran4()
                    }
                         label: {
                            Text("Ajouter cette activité")
                                .fontWeight(.bold)
                                .foregroundStyle(.black)
                                .padding()
                                .background(.orangec)
                                .cornerRadius(20)
                                .shadow(radius: 10, x: 1, y: 10)
                                               
                                    
                                        }
                
        }
             
            }
            .navigationTitle("Les Activités")
        }
        
    }
}

#Preview {
    Ecran_activite__8()
}
