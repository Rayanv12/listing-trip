//
//  ProfilView.swift
//  FirstAppl
//
//  Created by Apprenant66 on 15/03/2024.
//

import SwiftUI

struct ProfilView: View {
    var body: some View {
        ZStack {
            Color.jaune
            Text("Profil ici")
        }
      
    }
}

#Preview {
    ProfilView()
}
