//
//  application ecran 2.swift
//  FirstAppl
//
//  Created by Apprenant66 on 07/03/2024.
//

import SwiftUI

struct Ecran_3_linstingtrip: View {
    init() {
        UINavigationBar.appearance().largeTitleTextAttributes = [.foregroundColor: UIColor(Color("orangec"))]
    }
    
    var Sangria = Activité(titre: "Faites votre Sangria !", description: "Apprenez à faire votre sangria au coeur de Madrid. \rJavier, notre mixologue vous accompagne pour vous faire découvrir la sangria la plus délicieuse faite par vous ! L'activité commencera par un tour sur le marché de Madrid, afin de choisir les meilleures fruits frais et juteux.  ", image:"Rectangle 94-2", budjet:170, categorie: "Gastronomie" , choisi: false, adresse: "16 calle de purchena 28001 Madrid" , telephone: "+3408675432" , tempsActivitée: "1 heure", lienweb: "https://www.Sangriaday.com")
   
    var body: some View {
       
            ZStack {
                Color(.jaune)
            
                
                
                VStack {
                    
                    
                    VStack {
                        
                        ZStack {
                            Rectangle()
                                .frame(width: 130, height: 50)
                                .foregroundColor(.white)
                                .clipShape(UnevenRoundedRectangle(cornerRadii: .init(topLeading: 20, bottomLeading: 0, bottomTrailing: 0, topTrailing: 20)))
                                .shadow(color: .red, radius: 0, x: 8, y: 1)
                            
                            VStack {
                                Text(Sangria.categorie)
                                    .bold()
                                    .padding(.bottom, -4.0)
                                
                            }
                        }
                        
                        .padding(.trailing, 240.0)
                    }
                    
                    
                    .padding(.bottom, -9.0)
                    
                    VStack {
                        
                        
                        Image("sangria")
                            .resizable()
                            .scaledToFill()
                            .frame(width: 370, height: 150, alignment: .center)
                            .clipShape(UnevenRoundedRectangle(cornerRadii: .init(topLeading: 0, bottomLeading: 0, bottomTrailing: 0, topTrailing: 30)))
                            .shadow(radius: 10, x: 1, y: 10)
                        
                        
                            .padding(.bottom, -24.0)
                        // .padding(.horizontal, 19.0)
                        
                        
                        VStack {
                            ZStack{
                            Rectangle()
                             .clipShape(UnevenRoundedRectangle(cornerRadii: .init(topLeading: 0, bottomLeading: 30, bottomTrailing: 30, topTrailing: 0)))
                                .frame(width: 370, height: 380)
                                .foregroundColor(Color.white)
                                .shadow(radius: 10, x: 1, y: 10)

                            VStack (alignment: .leading) {
                                Text(Sangria.titre)
                                    .font(.largeTitle)
                                    .padding(.bottom)

                                Text("Tarifs de groupe: \(Sangria.budjet) €")
                                Text(Sangria.tempsActivitée)
                                Text(Sangria.adresse)
                                Text(Sangria.telephone)
                                
                                    .padding(.bottom)
                                Text(Sangria.description)
                                Text (Sangria.lienweb)
                                }
                            .padding(.horizontal, 19.0)
                          // .paddin (.bottom, 20) augmenter titre du texte
                            }
                     .padding()
                        }
                        
                        
                    }
                    
                    VStack {
                        NavigationLink {
                            application_ecran4()
                        } label: {
                            Text("Ajouter cette activité")
                                .fontWeight(.bold)
                                .foregroundStyle(.black)
                                .padding()
                                .background(.orangec)
                                .cornerRadius(20)
                                .shadow(radius: 10, x: 1, y: 10)
                               
                            
                        }
                        
                    }
                    
                }
                
                .navigationTitle("Les Activités")
                
            }
          
        }
      
}


#Preview {
    Ecran_3_linstingtrip()
}

