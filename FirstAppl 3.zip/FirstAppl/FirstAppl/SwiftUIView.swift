//
//  SwiftUIView.swift
//  FirstAppl
//
//  Created by Apprenant66 on 06/03/2024.
//

import SwiftUI

struct SwiftUIView: View {
    @State private var color: Color = .blue
    @State private var texte: String = "who is there?"
    
    var body: some View {
        VStack {
            Text("Knock,Knock")
                .font(.largeTitle)
                .padding(.vertical, 120)
            
            Button(action: {
                color = .blue
                texte = "me"
            },
           
                
                   label: {
                
                Text(texte)
                    .foregroundStyle(.white)
                    .padding()
                    .background(color)
                    .clipShape(RoundedRectangle(cornerRadius: 20))
    
            })
                   } // fin Vstack
                   }
                   }
                   
                   
                   #Preview {
                SwiftUIView()
            }
