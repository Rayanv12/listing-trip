//
//  Tabview.swift
//  FirstAppl
//
//  Created by Apprenant66 on 15/03/2024.
//

import SwiftUI

struct Tabview: View {
    
   
    var body: some View {
        ZStack {

            TabView {

             
                Ecran_1()
                    .tabItem {
                        Label ("Créer un voyage", systemImage: "plus.circle.fill")
                    }
               
                Ecran_5()
                    .tabItem {
                        Label ("Mes voyages", systemImage: "airplane.departure")
                    }
          
            } // fin tabview
            
            
            
            
            
            
            
            
            
            
            
            
            
        } //fin Zstack
    }
}

#Preview {
    Tabview()
}
